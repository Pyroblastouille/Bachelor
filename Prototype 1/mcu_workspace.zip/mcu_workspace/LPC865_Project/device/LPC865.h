/*
** ###################################################################
**     Processors:          LPC865M201JBD64
**                          LPC865M201JHI33
**                          LPC865M201JHI48
**
**     Compilers:           GNU C Compiler
**                          IAR ANSI C/C++ Compiler for ARM
**                          Keil ARM C/C++ Compiler
**                          MCUXpresso Compiler
**
**     Reference manual:    LPC86x User manual Rev.1  March 2022
**     Version:             rev. 1.0, 2022-03-15
**     Build:               b240704
**
**     Abstract:
**         CMSIS Peripheral Access Layer for LPC865
**
**     Copyright 1997-2016 Freescale Semiconductor, Inc.
**     Copyright 2016-2024 NXP
**     SPDX-License-Identifier: BSD-3-Clause
**
**     http:                 www.nxp.com
**     mail:                 support@nxp.com
**
**     Revisions:
**     - rev. 0.0 (2021-07-15)
**         Initial version.
**     - rev. 1.0 (2022-03-15)
**         Revesion of Rev. 1.
**
** ###################################################################
*/

/*!
 * @file LPC865.h
 * @version 1.0
 * @date 2022-03-15
 * @brief CMSIS Peripheral Access Layer for LPC865
 *
 * CMSIS Peripheral Access Layer for LPC865
 */

#if !defined(LPC865_H_)  /* Check if memory map has not been already included */
#define LPC865_H_

/* IP Header Files List */
#include "../device/periph3/PERI_ACOMP.h"
#include "../device/periph3/PERI_ADC.h"
#include "../device/periph3/PERI_CRC.h"
#include "../device/periph3/PERI_DMA.h"
#include "../device/periph3/PERI_FLASH_CTRL.h"
#include "../device/periph3/PERI_FTM.h"
#include "../device/periph3/PERI_GPIO.h"
#include "../device/periph3/PERI_I2C.h"
#include "../device/periph3/PERI_I3C.h"
#include "../device/periph3/PERI_INPUTMUX.h"
#include "../device/periph3/PERI_IOCON.h"
#include "../device/periph3/PERI_MRT.h"
#include "../device/periph3/PERI_PINT.h"
#include "../device/periph3/PERI_PMU.h"
#include "../device/periph3/PERI_SPI.h"
#include "../device/periph3/PERI_SWM.h"
#include "../device/periph3/PERI_SYSCON.h"
#include "../device/periph3/PERI_USART.h"
#include "../device/periph3/PERI_WKT.h"
#include "../device/periph3/PERI_WWDT.h"

#endif  /* #if !defined(LPC865_H_) */
