/*
 * proto_values.h
 * Contient les valeurs sur le prototype de plateau magnétiqu
 *
 *  Created on: 30 juil. 2025
 *      Author: gaelm
 */



#ifndef PROTO_VALUES_H_
#define PROTO_VALUES_H_



//Définit les pins GPIO des bobines
#define C1_V1_PH_PIN 18
#define C1_V1_EN_PIN 19
#define C1_V2_PH_PIN 7
#define C1_V2_EN_PIN 6
#define C1_V3_PH_PIN 7
#define C1_V3_EN_PIN 0
#define C1_H1_PH_PIN 14
#define C1_H1_EN_PIN 29
#define C1_H2_PH_PIN 23
#define C1_H2_EN_PIN 30
#define C1_H3_PH_PIN 22
#define C1_H3_EN_PIN 20
#define C2_H1_PH_PIN 8
#define C2_H1_EN_PIN 13
#define C2_H2_PH_PIN 9
#define C2_H2_EN_PIN 12
#define C2_H3_PH_PIN 21
#define C2_H3_EN_PIN 20
#define C2_V1_PH_PIN 21
#define C2_V1_EN_PIN 19
#define C2_V2_PH_PIN 18
#define C2_V2_EN_PIN 11
#define C2_V3_PH_PIN 17
#define C2_V3_EN_PIN 10
#define C3_V1_PH_PIN 13
#define C3_V1_EN_PIN 31
#define C3_V2_PH_PIN 0
#define C3_V2_EN_PIN 11
#define C3_V3_PH_PIN 10
#define C3_V3_EN_PIN 1
#define C3_H1_PH_PIN 16
#define C3_H1_EN_PIN 2
#define C3_H2_PH_PIN 27
#define C3_H2_EN_PIN 14
#define C3_H3_PH_PIN 26
#define C3_H3_EN_PIN 15
#define C4_H1_PH_PIN 25
#define C4_H1_EN_PIN 24
#define C4_H2_PH_PIN 3
#define C4_H2_EN_PIN 15
#define C4_H3_PH_PIN 4
#define C4_H3_EN_PIN 1
#define C4_V1_PH_PIN 9
#define C4_V1_EN_PIN 8
#define C4_V2_PH_PIN 5
#define C4_V2_EN_PIN 16
#define C4_V3_PH_PIN 17
#define C4_V3_EN_PIN 6

//Définit les ports GPIO des bobines
#define C1_V1_PH_PORT 1
#define C1_V1_EN_PORT 1
#define C1_V2_PH_PORT 0
#define C1_V2_EN_PORT 0
#define C1_V3_PH_PORT 1
#define C1_V3_EN_PORT 0
#define C1_H1_PH_PORT 0
#define C1_H1_EN_PORT 0
#define C1_H2_PH_PORT 0
#define C1_H2_EN_PORT 0
#define C1_H3_PH_PORT 0
#define C1_H3_EN_PORT 1
#define C2_H1_PH_PORT 0
#define C2_H1_EN_PORT 0
#define C2_H2_PH_PORT 1
#define C2_H2_EN_PORT 0
#define C2_H3_PH_PORT 0
#define C2_H3_EN_PORT 1
#define C2_V1_PH_PORT 0
#define C2_V1_EN_PORT 1
#define C2_V2_PH_PORT 1
#define C2_V2_EN_PORT 0
#define C2_V3_PH_PORT 1
#define C2_V3_EN_PORT 0
#define C3_V1_PH_PORT 1
#define C3_V1_EN_PORT 0
#define C3_V2_PH_PORT 1
#define C3_V2_EN_PORT 0
#define C3_V3_PH_PORT 0
#define C3_V3_EN_PORT 1
#define C3_H1_PH_PORT 0
#define C3_H1_EN_PORT 1
#define C3_H2_PH_PORT 0
#define C3_H2_EN_PORT 1
#define C3_H3_PH_PORT 0
#define C3_H3_EN_PORT 1
#define C4_H1_PH_PORT 0
#define C4_H1_EN_PORT 0
#define C4_H2_PH_PORT 1
#define C4_H2_EN_PORT 0
#define C4_H3_PH_PORT 1
#define C4_H3_EN_PORT 0
#define C4_V1_PH_PORT 0
#define C4_V1_EN_PORT 0
#define C4_V2_PH_PORT 1
#define C4_V2_EN_PORT 1
#define C4_V3_PH_PORT 1
#define C4_V3_EN_PORT 1


#endif /* PROTO_VALUES_H_ */
