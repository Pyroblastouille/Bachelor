/*
 * coil.c
 *
 *  Created on: 30 juil. 2025
 *      Author: gaelm
 */

#include "coil.h"

#include "LPC865_COMMON.h"
#include "fsl_gpio.h"


void create_coil(coil_t* coil,
		uint8_t pin_vert_1_en,uint8_t port_vert_1_en,
		uint8_t pin_vert_1_ph,uint8_t port_vert_1_ph,
		uint8_t pin_vert_2_en,uint8_t port_vert_2_en,
		uint8_t pin_vert_2_ph,uint8_t port_vert_2_ph,
		uint8_t pin_vert_3_en,uint8_t port_vert_3_en,
		uint8_t pin_vert_3_ph,uint8_t port_vert_3_ph,
		uint8_t pin_hori_1_en,uint8_t port_hori_1_en,
		uint8_t pin_hori_1_ph,uint8_t port_hori_1_ph,
		uint8_t pin_hori_2_en,uint8_t port_hori_2_en,
		uint8_t pin_hori_2_ph,uint8_t port_hori_2_ph,
		uint8_t pin_hori_3_en,uint8_t port_hori_3_en,
		uint8_t pin_hori_3_ph,uint8_t port_hori_3_ph){

	gpio_pin_config_t coil_config = {
	        kGPIO_DigitalOutput, 0,
	    };

	//Active les bobines verticales
	GPIO_PinInit(GPIO, port_vert_1_en, pin_vert_1_en, &coil_config);
	GPIO_PinInit(GPIO, port_vert_2_en, pin_vert_2_en, &coil_config);
	GPIO_PinInit(GPIO, port_vert_3_en, pin_vert_3_en, &coil_config);
	GPIO_PinInit(GPIO, port_vert_1_ph, pin_vert_1_ph, &coil_config);
	GPIO_PinInit(GPIO, port_vert_2_ph, pin_vert_2_ph, &coil_config);
	GPIO_PinInit(GPIO, port_vert_3_ph, pin_vert_3_ph, &coil_config);

	//Active les bobines horizontales
	GPIO_PinInit(GPIO, port_hori_1_en, pin_hori_1_en, &coil_config);
	GPIO_PinInit(GPIO, port_hori_2_en, pin_hori_2_en, &coil_config);
	GPIO_PinInit(GPIO, port_hori_3_en, pin_hori_3_en, &coil_config);
	GPIO_PinInit(GPIO, port_hori_1_ph, pin_hori_1_ph, &coil_config);
	GPIO_PinInit(GPIO, port_hori_2_ph, pin_hori_2_ph, &coil_config);
	GPIO_PinInit(GPIO, port_hori_3_ph, pin_hori_3_ph, &coil_config);

	//Stocke les pins
	coil->vert_1_en_pin = pin_vert_1_en;
	coil->vert_1_ph_pin = pin_vert_1_ph;
	coil->vert_2_en_pin = pin_vert_2_en;
	coil->vert_2_ph_pin = pin_vert_2_ph;
	coil->vert_3_en_pin = pin_vert_3_en;
	coil->hori_3_ph_pin = pin_hori_3_ph;
	coil->hori_1_en_pin = pin_hori_1_en;
	coil->hori_1_ph_pin = pin_hori_1_ph;
	coil->hori_2_en_pin = pin_hori_2_en;
	coil->hori_2_ph_pin = pin_hori_2_ph;
	coil->hori_3_en_pin = pin_hori_3_en;
	coil->hori_3_ph_pin = pin_hori_3_ph;

	//Stocke les ports
	coil->vert_1_en_port = port_vert_1_en;
	coil->vert_1_ph_port = port_vert_1_ph;
	coil->vert_2_en_port = port_vert_2_en;
	coil->vert_2_ph_port = port_vert_2_ph;
	coil->vert_3_en_port = port_vert_3_en;
	coil->hori_3_ph_port = port_hori_3_ph;
	coil->hori_1_en_port = port_hori_1_en;
	coil->hori_1_ph_port = port_hori_1_ph;
	coil->hori_2_en_port = port_hori_2_en;
	coil->hori_2_ph_port = port_hori_2_ph;
	coil->hori_3_en_port = port_hori_3_en;
	coil->hori_3_ph_port = port_hori_3_ph;
}


void wait_ticks(uint32_t ticks){
	volatile uint32_t i = 0;
	while(i < ticks){
		i++;
	}
}
void coil_movecycle_up(coil_t* self, uint32_t ticks_between_move){

	GPIO_PinWrite(GPIO, self->hori_1_en_port,self->hori_1_en_pin , 1);
	wait_ticks(ticks_between_move);
	GPIO_PinWrite(GPIO, self->hori_1_en_port,self->hori_1_en_pin , 0);
	GPIO_PinWrite(GPIO, self->hori_2_en_port,self->hori_2_en_pin , 1);
	wait_ticks(ticks_between_move);
	GPIO_PinWrite(GPIO, self->hori_2_en_port,self->hori_2_en_pin , 0);
	GPIO_PinWrite(GPIO, self->hori_3_en_port,self->hori_3_en_pin , 1);
	wait_ticks(ticks_between_move);
	GPIO_PinWrite(GPIO, self->hori_3_en_port,self->hori_3_en_pin , 0);
}

void coil_movecycle_down(coil_t* self, uint32_t ticks_between_move){

	GPIO_PinWrite(GPIO, self->hori_3_en_port,self->hori_3_en_pin , 1);
	wait_ticks(ticks_between_move);
	GPIO_PinWrite(GPIO, self->hori_3_en_port,self->hori_3_en_pin , 0);
	GPIO_PinWrite(GPIO, self->hori_2_en_port,self->hori_2_en_pin , 1);
	wait_ticks(ticks_between_move);
	GPIO_PinWrite(GPIO, self->hori_2_en_port,self->hori_2_en_pin , 0);
	GPIO_PinWrite(GPIO, self->hori_1_en_port,self->hori_1_en_pin , 1);
	wait_ticks(ticks_between_move);
	GPIO_PinWrite(GPIO, self->hori_1_en_port,self->hori_1_en_pin , 0);
}
void coil_movecycle_left(coil_t* self, uint32_t ticks_between_move){

	GPIO_PinWrite(GPIO, self->vert_1_en_port,self->vert_1_en_pin , 1);
	wait_ticks(ticks_between_move);
	GPIO_PinWrite(GPIO, self->vert_1_en_port,self->vert_1_en_pin , 0);
	GPIO_PinWrite(GPIO, self->vert_2_en_port,self->vert_2_en_pin , 1);
	wait_ticks(ticks_between_move);
	GPIO_PinWrite(GPIO, self->vert_2_en_port,self->vert_2_en_pin , 0);
	GPIO_PinWrite(GPIO, self->vert_3_en_port,self->vert_3_en_pin , 1);
	wait_ticks(ticks_between_move);
	GPIO_PinWrite(GPIO, self->vert_3_en_port,self->vert_3_en_pin , 0);
}
void coil_movecycle_right(coil_t* self, uint32_t ticks_between_move){

	GPIO_PinWrite(GPIO, self->vert_3_en_port,self->vert_3_en_pin , 1);
	wait_ticks(ticks_between_move);
	GPIO_PinWrite(GPIO, self->vert_3_en_port,self->vert_3_en_pin , 0);
	GPIO_PinWrite(GPIO, self->vert_2_en_port,self->vert_2_en_pin , 1);
	wait_ticks(ticks_between_move);
	GPIO_PinWrite(GPIO, self->vert_2_en_port,self->vert_2_en_pin , 0);
	GPIO_PinWrite(GPIO, self->vert_1_en_port,self->vert_1_en_pin , 1);
	wait_ticks(ticks_between_move);
	GPIO_PinWrite(GPIO, self->vert_1_en_port,self->vert_1_en_pin , 0);
}
