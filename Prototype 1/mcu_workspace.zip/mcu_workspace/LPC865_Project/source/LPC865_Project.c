/*
 * Copyright 2016-2025 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/**
 * @file    LPC865_Project.c
 * @brief   Application entry point.
 */


#define CPU_LPC865M201JBD64

#include <stdio.h>
#include "../board/board.h"
#include "../board/peripherals.h"
#include "../board/pin_mux.h"
#include "../board/clock_config.h"

/* TODO: insert other include files here. */
#include "coil.h"
#include "proto_values.h"
/* TODO: insert other definitions and declarations here. */

/*
 * @brief   Application entry point.
 */
int main(void) {

    /* Init board hardware. */
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();

    coil_t coil_1,coil_2,coil_3,coil_4;

    create_coil( &coil_1,
		C1_V1_EN_PIN, C1_V1_EN_PORT, C1_V1_PH_PIN, C1_V1_PH_PORT,
		C1_V2_EN_PIN, C1_V2_EN_PORT, C1_V2_PH_PIN, C1_V2_PH_PORT,
		C1_V3_EN_PIN, C1_V3_EN_PORT, C1_V3_PH_PIN, C1_V3_PH_PORT,
		C1_H1_EN_PIN, C1_H1_EN_PORT, C1_H1_PH_PIN, C1_H1_PH_PORT,
		C1_H2_EN_PIN, C1_H2_EN_PORT, C1_H2_PH_PIN, C1_H2_PH_PORT,
		C1_H3_EN_PIN, C1_H3_EN_PORT, C1_H3_PH_PIN, C1_H3_PH_PORT);
    create_coil(&coil_2,
		C2_V1_EN_PIN, C2_V1_EN_PORT, C2_V1_PH_PIN, C2_V1_PH_PORT,
		C2_V2_EN_PIN, C2_V2_EN_PORT, C2_V2_PH_PIN, C2_V2_PH_PORT,
		C2_V3_EN_PIN, C2_V3_EN_PORT, C2_V3_PH_PIN, C2_V3_PH_PORT,
		C2_H1_EN_PIN, C2_H1_EN_PORT, C2_H1_PH_PIN, C2_H1_PH_PORT,
		C2_H2_EN_PIN, C2_H2_EN_PORT, C2_H2_PH_PIN, C2_H2_PH_PORT,
		C2_H3_EN_PIN, C2_H3_EN_PORT, C2_H3_PH_PIN, C2_H3_PH_PORT);
    create_coil(&coil_3,
		C3_V1_EN_PIN, C3_V1_EN_PORT, C3_V1_PH_PIN, C3_V1_PH_PORT,
		C3_V2_EN_PIN, C3_V2_EN_PORT, C3_V2_PH_PIN, C3_V2_PH_PORT,
		C3_V3_EN_PIN, C3_V3_EN_PORT, C3_V3_PH_PIN, C3_V3_PH_PORT,
		C3_H1_EN_PIN, C3_H1_EN_PORT, C3_H1_PH_PIN, C3_H1_PH_PORT,
		C3_H2_EN_PIN, C3_H2_EN_PORT, C3_H2_PH_PIN, C3_H2_PH_PORT,
		C3_H3_EN_PIN, C3_H3_EN_PORT, C3_H3_PH_PIN, C3_H3_PH_PORT);
    create_coil(&coil_4,
		C4_V1_EN_PIN, C4_V1_EN_PORT, C4_V1_PH_PIN, C4_V1_PH_PORT,
		C4_V2_EN_PIN, C4_V2_EN_PORT, C4_V2_PH_PIN, C4_V2_PH_PORT,
		C4_V3_EN_PIN, C4_V3_EN_PORT, C4_V3_PH_PIN, C4_V3_PH_PORT,
		C4_H1_EN_PIN, C4_H1_EN_PORT, C4_H1_PH_PIN, C4_H1_PH_PORT,
		C4_H2_EN_PIN, C4_H2_EN_PORT, C4_H2_PH_PIN, C4_H2_PH_PORT,
		C4_H3_EN_PIN, C4_H3_EN_PORT, C4_H3_PH_PIN, C4_H3_PH_PORT);


    while(1) {
    	coil_movecycle_left(&coil_4,10000000);
    	coil_movecycle_down(&coil_3,10000000);
    	coil_movecycle_right(&coil_2,10000000);
		coil_movecycle_up(&coil_1,10000000);
    }
    return 0 ;
}
