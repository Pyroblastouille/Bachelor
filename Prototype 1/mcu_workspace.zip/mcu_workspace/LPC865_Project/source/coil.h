/*
 * coil.h
 *
 *  Created on: 30 juil. 2025
 *      Author: gaelm
 */

#ifndef COIL_H_
#define COIL_H_

#include "stdint.h"

typedef struct coil_s {
	uint8_t vert_1_en_pin;
	uint8_t vert_1_ph_pin;
	uint8_t vert_2_en_pin;
	uint8_t vert_2_ph_pin;
	uint8_t vert_3_en_pin;
	uint8_t vert_3_ph_pin;
	uint8_t hori_1_en_pin;
	uint8_t hori_1_ph_pin;
	uint8_t hori_2_en_pin;
	uint8_t hori_2_ph_pin;
	uint8_t hori_3_en_pin;
	uint8_t hori_3_ph_pin;

	uint8_t vert_1_en_port;
	uint8_t vert_1_ph_port;
	uint8_t vert_2_en_port;
	uint8_t vert_2_ph_port;
	uint8_t vert_3_en_port;
	uint8_t vert_3_ph_port;
	uint8_t hori_1_en_port;
	uint8_t hori_1_ph_port;
	uint8_t hori_2_en_port;
	uint8_t hori_2_ph_port;
	uint8_t hori_3_en_port;
	uint8_t hori_3_ph_port;
} coil_t;


void create_coil( coil_t* coil,
		uint8_t pin_vert_1_en,uint8_t port_vert_1_en,
		uint8_t pin_vert_1_ph,uint8_t port_vert_1_ph,
		uint8_t pin_vert_2_en,uint8_t port_vert_2_en,
		uint8_t pin_vert_2_ph,uint8_t port_vert_2_ph,
		uint8_t pin_vert_3_en,uint8_t port_vert_3_en,
		uint8_t pin_vert_3_ph,uint8_t port_vert_3_ph,
		uint8_t pin_hori_1_en,uint8_t port_hori_1_en,
		uint8_t pin_hori_1_ph,uint8_t port_hori_1_ph,
		uint8_t pin_hori_2_en,uint8_t port_hori_2_en,
		uint8_t pin_hori_2_ph,uint8_t port_hori_2_ph,
		uint8_t pin_hori_3_en,uint8_t port_hori_3_en,
		uint8_t pin_hori_3_ph,uint8_t port_hori_3_ph);


void wait_ticks(uint32_t ticks);


void coil_movecycle_up(coil_t* self, uint32_t ticks_between_move);
void coil_movecycle_down(coil_t* self, uint32_t ticks_between_move);
void coil_movecycle_left(coil_t* self, uint32_t ticks_between_move);
void coil_movecycle_right(coil_t* self, uint32_t ticks_between_move);
void coil_movecycle_upleft(coil_t* self, uint32_t ticks_between_move);
void coil_movecycle_upright(coil_t* self, uint32_t ticks_between_move);
void coil_movecycle_downleft(coil_t* self, uint32_t ticks_between_move);
void coil_movecycle_downright(coil_t* self, uint32_t ticks_between_move);

#endif /* COIL_H_ */
