/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2022 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_gpio.h"
#include "app.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define APP_SW_STATE_RELEASED         0U
#define APP_SW_STATE_CONFIRM_PRESSED  1U
#define APP_SW_STATE_PRESSED          2U
#define APP_SW_STATE_CONFIRM_RELEASED 3U
#define APP_SW_FILTER_PERIOD          5

#define MS_BETWEEN_TICKS 1000

#define PORT_V1_PH 1
#define PIN_V1_PH 13
#define PORT_V1_EN 0
#define PIN_V1_EN 31
#define PORT_V2_PH 1
#define PIN_V2_PH 0
#define PORT_V2_EN 0
#define PIN_V2_EN 11
#define PORT_V3_PH 0
#define PIN_V3_PH 10
#define PORT_V3_EN 1
#define PIN_V3_EN 1

/*******************************************************************************
 * Prototypes
 ******************************************************************************/


/*******************************************************************************
 * Variables
 ******************************************************************************/
volatile uint32_t g_systickCounter;
uint8_t swState = APP_SW_STATE_RELEASED;
int8_t filter   = -1;

/*******************************************************************************
 * Code
 ******************************************************************************/
void SysTick_Handler(void)
{
    if (g_systickCounter != 0U)
    {
        g_systickCounter--;
    }
}

void SysTick_DelayTicks(uint32_t n)
{
    g_systickCounter = n;
    while (g_systickCounter != 0U)
    {
    }
}

void coil_movecycle_up(uint32_t ticks_between_move){

	GPIO_PinWrite(GPIO, PORT_V1_EN,PIN_V1_EN, 1);
	SysTick_DelayTicks(ticks_between_move);
	GPIO_PinWrite(GPIO, PORT_V1_EN,PIN_V1_EN, 0);
	GPIO_PinWrite(GPIO, PORT_V2_EN,PIN_V2_EN, 1);
	SysTick_DelayTicks(ticks_between_move);
	GPIO_PinWrite(GPIO, PORT_V2_EN,PIN_V2_EN, 0);
	GPIO_PinWrite(GPIO, PORT_V3_EN,PIN_V3_EN, 1);
	SysTick_DelayTicks(ticks_between_move);
	GPIO_PinWrite(GPIO, PORT_V3_EN,PIN_V3_EN, 0);
}

void coil_movecycle_down(uint32_t ticks_between_move){
	GPIO_PinWrite(GPIO, PORT_V3_EN,PIN_V3_EN, 1);
	SysTick_DelayTicks(ticks_between_move);
	GPIO_PinWrite(GPIO, PORT_V3_EN,PIN_V3_EN, 0);
	GPIO_PinWrite(GPIO, PORT_V2_EN,PIN_V2_EN, 1);
	SysTick_DelayTicks(ticks_between_move);
	GPIO_PinWrite(GPIO, PORT_V2_EN,PIN_V2_EN, 0);
	GPIO_PinWrite(GPIO, PORT_V1_EN,PIN_V1_EN, 1);
	SysTick_DelayTicks(ticks_between_move);
	GPIO_PinWrite(GPIO, PORT_V1_EN,PIN_V1_EN, 0);
}


/*!
 * @brief Main function
 */
int main(void)
{
    /* Define the init structure for the output LED pin*/
    gpio_pin_config_t led_config = {
        kGPIO_DigitalOutput,
        0,
    };

    /* Board pin, clock, debug console init */
    BOARD_InitHardware();


    /* Init output LED GPIO. */
    GPIO_PortInit(GPIO, 1);
    GPIO_PortInit(GPIO, 0);

    GPIO_PinInit(GPIO, PORT_V1_EN, PIN_V1_EN, &led_config);
    GPIO_PinInit(GPIO, PORT_V1_PH, PIN_V1_PH, &led_config);
    GPIO_PinInit(GPIO, PORT_V2_EN, PIN_V2_EN, &led_config);
    GPIO_PinInit(GPIO, PORT_V2_PH, PIN_V2_PH, &led_config);
    GPIO_PinInit(GPIO, PORT_V3_EN, PIN_V3_EN, &led_config);
    GPIO_PinInit(GPIO, PORT_V3_PH, PIN_V3_PH, &led_config);


    /* Set systick reload value to generate 1ms interrupt */
    if (SysTick_Config(SystemCoreClock / 1000U))
    {
        while (1)
        {
        }
    }

    while (1)
    {
    	coil_movecycle_up(MS_BETWEEN_TICKS);
    	coil_movecycle_down(MS_BETWEEN_TICKS);
    }
}
